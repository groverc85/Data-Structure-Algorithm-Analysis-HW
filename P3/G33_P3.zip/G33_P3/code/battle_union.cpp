#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int fa[1001];
int a[5000][4];

void unionset(int x, int y);
int findfa(int x);
int main()
{
    //----------------------
    FILE *fp1, *fp2;
    freopen("battle8.txt","r",stdin);
    freopen("battle_r.txt","w",stdout);
    //----------------------*/
    
    int n,m;
    int i,j;
    scanf("%d %d\n", &n, &m);
    while (n!=0)
    {
        for (i=1; i<=m; i++) scanf("%d %d %d %d\n", &a[i][1], &a[i][2], &a[i][3], &a[i][0]);
        int max=-1;
        int ans[1001];
        for (i=1; i<=n; i++)
        {
            int f=1;
            for (j=1; j<=n; j++) fa[j]=j;
            for (j=1; j<=m; j++)
                if ((a[j][1]!=i)&&(a[j][2]!=i)) 
                   if (a[j][0]==1) unionset(a[j][1],a[j][2]);
            int min=19940823;
            for (j=1; j<=m; j++)
                if ((findfa(a[j][1])!=findfa(a[j][2]))&&(a[j][1]!=i)&&(a[j][2]!=i))
                {
                   f=-1;
                   if ((a[j][0]==0)&&(min>a[j][3]))
                      min=a[j][3];
                }
                
            for (j=1; j<=i-2; j++) 
                if (findfa(j)!=findfa(j+1)) f=-1;
            for (j=i+1; j<=n-1; j++) 
                if (findfa(j)!=findfa(j+1)) f=-1;
            if ((findfa(i-1)!=findfa(i+1))&&(i!=1)&&(i!=n)) f=-1;
              
            if ((min>max)&&(f!=1)){
                                   ans[0]=1;
                                   ans[ans[0]]=i;
                                   max=min;
                                  }
            else if ((min==max)&&(f!=1)){
                                           ans[0]++;
                                           ans[ans[0]]=i;
                                        }
        }
        if (max==-1) {
                     ans[0]=1;
                     ans[1]=0;
                     }
        for (i=1;i<ans[0];i++) printf("%d ", ans[i]);
        printf("%d\n", ans[ans[0]]);        
        scanf("%d %d\n", &n, &m);
    }
    return 0;
}
 
void unionset(int x, int y)
{
     x=findfa(x);
     y=findfa(y);
     fa[x]=y;
}
int findfa(int x)
{
	if (x==fa[x]) return fa[x];
	fa[x]=findfa(fa[x]);
	return fa[x];
}
