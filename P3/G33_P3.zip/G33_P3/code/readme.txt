cy_G33_P3.c is the source code;
cy_G33_P3.exe is the executable file;
battle_union.cpp is the code improved;
battle_union.exe is the executable file of improved code;
data.zip is the data that we used in this project.