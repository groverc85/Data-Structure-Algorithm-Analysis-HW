/*
Task Name:battle over cities         
Coder:Henry                   
IDE:Dev Cpp 5.4.2   
Time:2013.10.28 
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int cost[1001][1001];//store the distance by adjacent matrix 
int state[1001][1001];//store the state of the edge
int map[1001][1001];//a new adjacent matrix 
int s[1001];//disjoint sets
int outmax[1001]; //output queue of city numbers
int maxn,max,part; 
int mincost,sum,l,r;
int n,m,i,j,k,first;
int city1,city2,cost1,state1;

int lowcost[1001];
int v[1001];

void find(int left,int sign,int del) 
//mark cities connected with the same sign as floodfill algorithm
{
  int right;
  s[left]=sign;//mark the city
  for(right=1;right<=n;right++)
	  if((cost[left][right]!=0)&&(state[left][right]==1)&&
		   (s[right]==0)&&(right!=del))
		      find(right,sign,del); //mark other cities connected with it in a recursion process

}

int main()
{

    scanf("%d",&n);
	while(n!=0)
	{
        scanf("%d",&m);
		memset(cost,0,sizeof(cost));
		memset(state,0,sizeof(state)); //initializing
		
		for(i=1;i<=m;i++)
		{
           scanf("%d %d %d %d",&city1,&city2,&cost1,&state1);
		   cost[city1][city2]=cost1;
		   cost[city2][city1]=cost1;   //the ways are undirected
		   state[city1][city2]=state1;
		   state[city2][city1]=state1;
		}      //initialize adjacetn matrix 
        
		max=0;
        maxn=0;
        memset(outmax,0,sizeof(outmax)); 
		
		for(i=1;i<=n;i++)
		{
			memset(s,0,sizeof(s));  
			part=0;
			for(first=1;first<=n;first++)
			{
				if((first!=i)&&(s[first]==0))
			       find(first,++part,i);
			} //find how many parts were separated
            
			for(l=1;l<=part;l++)
				for(r=1;r<=part;r++)
					if(l!=r)
						map[l][r]=10000;//initialize new map

			for(l=1;l<=n;l++)
				for(r=1;r<=n;r++)
					if((s[l]!=s[r])&&
						(state[l][r]==0)&&(cost[l][r]!=0)
						  &&(cost[l][r]<map[s[l]][s[r]]))
						    map[s[l]][s[r]]=cost[l][r];
			//here we make the cities connected degenerate to be one city
            
			for(j=1;j<=part;j++)
			{
				lowcost[j]=map[1][j];
				v[j]=0;
			}
			
            sum=0;//recording minimum cost to connect all the cities

			v[1]=1;
			for(j=1;j<=part;j++)
			{    
 				if(v[j]==0)
				{
				mincost=10000;
				for(k=1;k<=part;k++)
			      if((v[k]!=0)&&(map[k][j]<mincost))
					  mincost=map[k][j];
				lowcost[j]=mincost;
				sum+=mincost;
				}
			}      //process of minimun spanning tree
            
            if(sum>max)
			{
				maxn=1;
				outmax[maxn]=i;
				max=sum;
			}
			else 
				if((sum==max)&&(sum!=0))
				{
					maxn++;
                    outmax[maxn]=i;
				} //record the maximum 

		}
		if(maxn==0)
		   printf("0");
		else
		  {	
		    for(i=1;i<=maxn-1;i++)
		 	    printf("%d ",outmax[i]);
		    printf("%d",outmax[maxn]);
	     }  //output process
		printf("\n");
		scanf("%d",&n);
	}
    return 0;
}
